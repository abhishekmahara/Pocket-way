<?php
require_once '../includes/auth-check.php';
require_once '../includes/db-config.php';
require_once '../includes/admin-header.php';

// Fetch basic statistics
try {
    $stats = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM routes) as routes,
            (SELECT COUNT(*) FROM stations) as stations,
            (SELECT COUNT(*) FROM buses) as buses,
            (SELECT COUNT(*) FROM fares) as fares,
            (SELECT COUNT(*) FROM route_maps) as maps
        FROM dual
    ")->fetch();
} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $stats = [];
}
?>

<style>
.dashboard-container {
    padding: 2rem;
}

.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.action-card {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    text-align: center;
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.action-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: var(--primary);
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 600;
    margin: 0.5rem 0;
    color: var(--primary-dark);
}

.management-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 3rem;
}

.section-card {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.section-header {
    display: flex;
    align-items: center;
    margin-bottom: 1.5rem;
}

.section-icon {
    font-size: 1.5rem;
    margin-right: 1rem;
    color: var(--primary);
}

.action-list {
    list-style: none;
    padding: 0;
}

.action-item {
    padding: 1rem;
    border-radius: 10px;
    margin-bottom: 0.5rem;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #333;
}

.action-item:hover {
    background: rgba(0,123,127,0.1);
    transform: translateX(5px);
}
</style>

<div class="dashboard-container">
    <!-- Welcome Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></h2>
        <div class="text-muted"><?php echo date('l, F j, Y'); ?></div>
    </div>

    <!-- Quick Stats -->
    <div class="quick-actions">
        <div class="action-card">
            <i class="fas fa-route action-icon"></i>
            <h3>Routes</h3>
            <div class="stat-value"><?php echo number_format($stats['routes']); ?></div>
            <a href="routes/manage-routes.php" class="btn btn-sm btn-primary">Manage Routes</a>
        </div>
        
        <div class="action-card">
            <i class="fas fa-map-marker-alt action-icon"></i>
            <h3>Stations</h3>
            <div class="stat-value"><?php echo number_format($stats['stations']); ?></div>
            <a href="stations/manage-stations.php" class="btn btn-sm btn-primary">Manage Stations</a>
        </div>
        
        <div class="action-card">
            <i class="fas fa-bus action-icon"></i>
            <h3>Buses</h3>
            <div class="stat-value"><?php echo number_format($stats['buses']); ?></div>
            <a href="buses/manage-buses.php" class="btn btn-sm btn-primary">Manage Fleet</a>
        </div>
        
        <div class="action-card">
            <i class="fas fa-money-bill action-icon"></i>
            <h3>Fares</h3>
            <div class="stat-value"><?php echo number_format($stats['fares']); ?></div>
            <a href="fares/manage-fares.php" class="btn btn-sm btn-primary">Manage Fares</a>
        </div>
    </div>

    <!-- Management Sections -->
    <div class="management-section">
        <!-- Route Management -->
        <div class="section-card">
            <div class="section-header">
                <i class="fas fa-route section-icon"></i>
                <h4>Route Management</h4>
            </div>
            <div class="action-list">
                <a href="routes/add-route.php" class="action-item">
                    <i class="fas fa-plus-circle me-2"></i> Add New Route
                </a>
                <a href="routes/manage-routes.php" class="action-item">
                    <i class="fas fa-list me-2"></i> View All Routes
                </a>
                <a href="maps/upload-map.php" class="action-item">
                    <i class="fas fa-map me-2"></i> Upload Route Map
                </a>
            </div>
        </div>

        <!-- Station Management -->
        <div class="section-card">
            <div class="section-header">
                <i class="fas fa-map-marker-alt section-icon"></i>
                <h4>Station Management</h4>
            </div>
            <div class="action-list">
                <a href="stations/add-station.php" class="action-item">
                    <i class="fas fa-plus-circle me-2"></i> Add New Station
                </a>
                <a href="stations/manage-stations.php" class="action-item">
                    <i class="fas fa-list me-2"></i> View All Stations
                </a>
                <a href="fares/manage-fares.php" class="action-item">
                    <i class="fas fa-money-bill me-2"></i> Manage Fares
                </a>
            </div>
        </div>

        <!-- Bus Management -->
        <div class="section-card">
            <div class="section-header">
                <i class="fas fa-bus section-icon"></i>
                <h4>Bus Management</h4>
            </div>
            <div class="action-list">
                <a href="buses/add-bus.php" class="action-item">
                    <i class="fas fa-plus-circle me-2"></i> Add New Bus
                </a>
                <a href="buses/manage-buses.php" class="action-item">
                    <i class="fas fa-list me-2"></i> View Fleet
                </a>
                <a href="timings/manage-timings.php" class="action-item">
                    <i class="fas fa-clock me-2"></i> Manage Schedules
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/admin-footer.php'; ?>