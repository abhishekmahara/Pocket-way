<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has timing_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['timing_id'])) {
    $timing_id = intval($_POST['timing_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Get timing details for logging
        $stmt = $pdo->prepare("
            SELECT bt.*, r.route_name, b.bus_name 
            FROM bus_timings bt
            JOIN routes r ON bt.route_id = r.route_id
            LEFT JOIN buses b ON bt.bus_id = b.id
            WHERE bt.id = ?
        ");
        $stmt->execute([$timing_id]);
        $timing = $stmt->fetch();

        if (!$timing) {
            throw new Exception('Timing not found');
        }

        // Delete associated records in order
        $statements = [
            "DELETE FROM timing_changes WHERE timing_id = ?",
            "DELETE FROM bus_timings WHERE id = ?"
        ];

        foreach ($statements as $sql) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$timing_id]);
        }

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log(sprintf(
            "Timing deleted: ID %d, Route: %s, Bus: %s, Time: %s by admin %s",
            $timing_id,
            $timing['route_name'],
            $timing['bus_name'] ?? 'No bus',
            $timing['departure_time'],
            $_SESSION['admin_username']
        ));

        $response['success'] = true;
        $response['message'] = 'Timing deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Timing deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access or invalid requests
    header('Location: manage-timings.php');
    exit;
}