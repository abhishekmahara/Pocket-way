<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/admin-header.php';
require_once '../../includes/db-config.php';

try {
    // Fetch all timings with detailed information
    $query = "
        SELECT bt.*, 
               r.route_name,
               b.bus_name,
               b.bus_number,
               COUNT(DISTINCT s.station_id) as total_stops
        FROM bus_timings bt
        JOIN routes r ON bt.route_id = r.route_id
        LEFT JOIN buses b ON bt.bus_id = b.id
        LEFT JOIN route_stations s ON r.route_id = s.route_id
        GROUP BY bt.id
        ORDER BY bt.departure_time ASC";
    
    $timings = $pdo->query($query)->fetchAll();
} catch (PDOException $e) {
    error_log("Timing listing error: " . $e->getMessage());
    $error = "Error loading timings";
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Manage Bus Timings</h1>
        <a href="add-timing.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Timing
        </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-clock me-1"></i>
            Bus Schedule
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="timingsTable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Route</th>
                            <th>Bus Details</th>
                            <th>Schedule</th>
                            <th>Stops</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($timings as $timing): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo htmlspecialchars($timing['route_name']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($timing['bus_name']): ?>
                                        <strong><?php echo htmlspecialchars($timing['bus_name']); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            Bus #<?php echo htmlspecialchars($timing['bus_number']); ?>
                                        </small>
                                    <?php else: ?>
                                        <span class="text-warning">No bus assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-clock text-primary me-2"></i>
                                        <div>
                                            <strong>
                                                <?php echo date('h:i A', strtotime($timing['departure_time'])); ?>
                                            </strong>
                                            <?php if ($timing['arrival_time']): ?>
                                                <br>
                                                <small class="text-muted">
                                                    Est. Arrival: <?php echo date('h:i A', strtotime($timing['arrival_time'])); ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo $timing['total_stops']; ?> stops
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                    $status = $timing['status'] ?? 'active';
                                    $statusClass = match($status) {
                                        'active' => 'success',
                                        'cancelled' => 'danger',
                                        default => 'warning'
                                    };
                                    ?>
                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                        <?php echo ucfirst($status); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit-timing.php?id=<?php echo $timing['id']; ?>" 
                                           class="btn btn-sm btn-warning"
                                           data-bs-toggle="tooltip"
                                           title="Edit Timing">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" 
                                                class="btn btn-sm btn-danger"
                                                onclick="deleteTiming(<?php echo $timing['id']; ?>)"
                                                data-bs-toggle="tooltip"
                                                title="Delete Timing">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#timingsTable').DataTable({
        pageLength: 25,
        order: [[2, 'asc']],
        responsive: true
    });
});

function deleteTiming(timingId) {
    if (confirm('Are you sure you want to delete this timing? This action cannot be undone.')) {
        fetch('delete-timing.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'timing_id=' + timingId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the timing');
        });
    }
}
</script>

<?php require_once '../../includes/admin-footer.php'; ?>