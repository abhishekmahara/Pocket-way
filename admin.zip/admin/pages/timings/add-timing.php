<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch active routes and their buses
    $query = "
        SELECT r.route_id, r.route_name,
               b.id as bus_id, b.bus_name, b.bus_number
        FROM routes r
        LEFT JOIN buses b ON r.route_id = b.route_id
        WHERE r.is_active = 1 AND (b.status = 'active' OR b.status IS NULL)
        ORDER BY r.route_name, b.bus_name";
    
    $stmt = $pdo->query($query);
    $routes = [];
    while ($row = $stmt->fetch()) {
        if (!isset($routes[$row['route_id']])) {
            $routes[$row['route_id']] = [
                'route_name' => $row['route_name'],
                'buses' => []
            ];
        }
        if ($row['bus_id']) {
            $routes[$row['route_id']]['buses'][] = $row;
        }
    }
} catch (PDOException $e) {
    error_log("Error fetching routes/buses: " . $e->getMessage());
    $error = "Unable to load routes";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $route_id = intval($_POST['route_id']);
    $bus_id = !empty($_POST['bus_id']) ? intval($_POST['bus_id']) : null;
    $departure_time = $_POST['departure_time'];
    $arrival_time = !empty($_POST['arrival_time']) ? $_POST['arrival_time'] : null;
    $frequency = $_POST['frequency'] ?? 'daily';
    $status = $_POST['status'] ?? 'active';

    if (empty($route_id) || empty($departure_time)) {
        $error = 'Route and departure time are required';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO bus_timings (
                    route_id, bus_id, departure_time, 
                    arrival_time, frequency, status, 
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            
            $stmt->execute([
                $route_id, $bus_id, $departure_time,
                $arrival_time, $frequency, $status
            ]);
            
            $_SESSION['success'] = 'Bus timing added successfully';
            header('Location: manage-timings.php');
            exit;
        } catch (PDOException $e) {
            error_log("Timing addition error: " . $e->getMessage());
            $error = 'Error adding timing. Please try again.';
        }
    }
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Add New Bus Timing</h1>
        <a href="manage-timings.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Timings
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-clock me-1"></i>
            Timing Details
        </div>
        <div class="card-body">
            <form method="POST" action="" id="timingForm">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="route_id" class="form-label">Select Route</label>
                        <select class="form-select" id="route_id" name="route_id" required>
                            <option value="">Select a route</option>
                            <?php foreach ($routes as $id => $route): ?>
                                <option value="<?php echo $id; ?>">
                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="bus_id" class="form-label">Assign Bus (Optional)</label>
                        <select class="form-select" id="bus_id" name="bus_id">
                            <option value="">No bus assigned</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="departure_time" class="form-label">Departure Time</label>
                        <input type="time" 
                               class="form-control" 
                               id="departure_time" 
                               name="departure_time" 
                               required>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="arrival_time" class="form-label">Estimated Arrival</label>
                        <input type="time" 
                               class="form-control" 
                               id="arrival_time" 
                               name="arrival_time">
                        <small class="text-muted">Optional</small>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="frequency" class="form-label">Frequency</label>
                        <select class="form-select" id="frequency" name="frequency">
                            <option value="daily">Daily</option>
                            <option value="weekday">Weekdays Only</option>
                            <option value="weekend">Weekends Only</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="active">Active</option>
                        <option value="scheduled">Scheduled</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Timing
                    </button>
                    <a href="manage-timings.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Store bus data
    const routeBuses = <?php echo json_encode($routes); ?>;

    // Update bus dropdown when route changes
    $('#route_id').change(function() {
        const routeId = $(this).val();
        const busSelect = $('#bus_id');
        busSelect.empty().append('<option value="">No bus assigned</option>');
        
        if (routeId && routeBuses[routeId] && routeBuses[routeId].buses.length > 0) {
            routeBuses[routeId].buses.forEach(bus => {
                busSelect.append(`
                    <option value="${bus.bus_id}">
                        ${bus.bus_name} (${bus.bus_number})
                    </option>
                `);
            });
        }
    });

    // Form validation
    $('#timingForm').submit(function(e) {
        const departure = $('#departure_time').val();
        const arrival = $('#arrival_time').val();
        
        if (arrival && arrival <= departure) {
            e.preventDefault();
            alert('Arrival time must be after departure time');
            return false;
        }
        return true;
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>