<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Validate timing ID
if (!isset($_GET['id'])) {
    header('Location: manage-timings.php');
    exit;
}

$timing_id = intval($_GET['id']);

try {
    // Fetch timing details with route and bus info
    $stmt = $pdo->prepare("
        SELECT bt.*, r.route_name
        FROM bus_timings bt
        JOIN routes r ON bt.route_id = r.route_id
        WHERE bt.id = ?
    ");
    $stmt->execute([$timing_id]);
    $timing = $stmt->fetch();

    if (!$timing) {
        $_SESSION['error'] = 'Timing not found';
        header('Location: manage-timings.php');
        exit;
    }

    // Fetch all active routes and their buses
    $query = "
        SELECT r.route_id, r.route_name,
               b.id as bus_id, b.bus_name, b.bus_number
        FROM routes r
        LEFT JOIN buses b ON r.route_id = b.route_id
        WHERE r.is_active = 1 AND (b.status = 'active' OR b.status IS NULL)
        ORDER BY r.route_name, b.bus_name";
    
    $stmt = $pdo->query($query);
    $routes = [];
    while ($row = $stmt->fetch()) {
        if (!isset($routes[$row['route_id']])) {
            $routes[$row['route_id']] = [
                'route_name' => $row['route_name'],
                'buses' => []
            ];
        }
        if ($row['bus_id']) {
            $routes[$row['route_id']]['buses'][] = $row;
        }
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $route_id = intval($_POST['route_id']);
        $bus_id = !empty($_POST['bus_id']) ? intval($_POST['bus_id']) : null;
        $departure_time = $_POST['departure_time'];
        $arrival_time = !empty($_POST['arrival_time']) ? $_POST['arrival_time'] : null;
        $frequency = $_POST['frequency'] ?? 'daily';
        $status = $_POST['status'] ?? 'active';

        if (empty($route_id) || empty($departure_time)) {
            $error = 'Route and departure time are required';
        } else {
            $stmt = $pdo->prepare("
                UPDATE bus_timings 
                SET route_id = ?, 
                    bus_id = ?,
                    departure_time = ?,
                    arrival_time = ?,
                    frequency = ?,
                    status = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            
            $stmt->execute([
                $route_id, $bus_id, $departure_time,
                $arrival_time, $frequency, $status,
                $timing_id
            ]);
            
            $_SESSION['success'] = 'Bus timing updated successfully';
            header('Location: manage-timings.php');
            exit;
        }
    }
} catch (PDOException $e) {
    error_log("Timing edit error: " . $e->getMessage());
    $error = 'System error, please try again later';
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Edit Bus Timing</h1>
        <a href="manage-timings.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Timings
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-clock me-1"></i>
            Timing Details
        </div>
        <div class="card-body">
            <form method="POST" action="" id="timingForm">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="route_id" class="form-label">Select Route</label>
                        <select class="form-select" id="route_id" name="route_id" required>
                            <option value="">Select a route</option>
                            <?php foreach ($routes as $id => $route): ?>
                                <option value="<?php echo $id; ?>"
                                    <?php echo ($timing['route_id'] == $id) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="bus_id" class="form-label">Assign Bus (Optional)</label>
                        <select class="form-select" id="bus_id" name="bus_id">
                            <option value="">No bus assigned</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="departure_time" class="form-label">Departure Time</label>
                        <input type="time" 
                               class="form-control" 
                               id="departure_time" 
                               name="departure_time" 
                               required
                               value="<?php echo $timing['departure_time']; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="arrival_time" class="form-label">Estimated Arrival</label>
                        <input type="time" 
                               class="form-control" 
                               id="arrival_time" 
                               name="arrival_time"
                               value="<?php echo $timing['arrival_time']; ?>">
                        <small class="text-muted">Optional</small>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="frequency" class="form-label">Frequency</label>
                        <select class="form-select" id="frequency" name="frequency">
                            <option value="daily" <?php echo $timing['frequency'] == 'daily' ? 'selected' : ''; ?>>Daily</option>
                            <option value="weekday" <?php echo $timing['frequency'] == 'weekday' ? 'selected' : ''; ?>>Weekdays Only</option>
                            <option value="weekend" <?php echo $timing['frequency'] == 'weekend' ? 'selected' : ''; ?>>Weekends Only</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="active" <?php echo $timing['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="scheduled" <?php echo $timing['status'] == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                        <option value="cancelled" <?php echo $timing['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Timing
                    </button>
                    <a href="manage-timings.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    const routeBuses = <?php echo json_encode($routes); ?>;
    const currentBusId = <?php echo $timing['bus_id'] ?? 'null'; ?>;

    function updateBusOptions(routeId) {
        const busSelect = $('#bus_id');
        busSelect.empty().append('<option value="">No bus assigned</option>');
        
        if (routeId && routeBuses[routeId] && routeBuses[routeId].buses.length > 0) {
            routeBuses[routeId].buses.forEach(bus => {
                busSelect.append(`
                    <option value="${bus.bus_id}" ${bus.bus_id == currentBusId ? 'selected' : ''}>
                        ${bus.bus_name} (${bus.bus_number})
                    </option>
                `);
            });
        }
    }

    // Initialize bus dropdown
    updateBusOptions($('#route_id').val());

    // Update bus dropdown when route changes
    $('#route_id').change(function() {
        updateBusOptions($(this).val());
    });

    // Form validation
    $('#timingForm').submit(function(e) {
        const departure = $('#departure_time').val();
        const arrival = $('#arrival_time').val();
        
        if (arrival && arrival <= departure) {
            e.preventDefault();
            alert('Arrival time must be after departure time');
            return false;
        }
        return true;
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>