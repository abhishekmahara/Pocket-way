<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch buses with complete information
    $query = "
        SELECT b.*, 
               r.route_name,
               COUNT(DISTINCT bt.id) as scheduled_trips,
               (SELECT COUNT(*) FROM bus_maintenance WHERE bus_id = b.id AND status = 'active') as maintenance_count
        FROM buses b
        LEFT JOIN routes r ON b.route_id = r.route_id
        LEFT JOIN bus_timings bt ON b.id = bt.bus_id
        GROUP BY b.id
        ORDER BY b.bus_name";
    
    $buses = $pdo->query($query)->fetchAll();
} catch (PDOException $e) {
    error_log("Bus listing error: " . $e->getMessage());
    $error = "Error loading buses";
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Manage Buses</h1>
        <a href="add-bus.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Bus
        </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-bus me-1"></i>
            Bus Fleet
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="busesTable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Bus Details</th>
                            <th>Route</th>
                            <th>Status</th>
                            <th>Statistics</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($buses as $bus): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($bus['bus_name']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        Number: <?php echo htmlspecialchars($bus['bus_number']); ?>
                                        <br>
                                        Type: <?php echo htmlspecialchars($bus['bus_type']); ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if ($bus['route_name']): ?>
                                        <span class="badge bg-info">
                                            <?php echo htmlspecialchars($bus['route_name']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">No Route Assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $statusClass = match($bus['status']) {
                                        'active' => 'success',
                                        'maintenance' => 'warning',
                                        default => 'danger'
                                    };
                                    ?>
                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                        <?php echo ucfirst($bus['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small>
                                        <i class="fas fa-clock"></i> <?php echo $bus['scheduled_trips']; ?> trips
                                        <br>
                                        <i class="fas fa-tools"></i> <?php echo $bus['maintenance_count']; ?> maintenance records
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit-bus.php?id=<?php echo $bus['id']; ?>" 
                                           class="btn btn-sm btn-warning"
                                           data-bs-toggle="tooltip"
                                           title="Edit Bus">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="view-bus.php?id=<?php echo $bus['id']; ?>" 
                                           class="btn btn-sm btn-info"
                                           data-bs-toggle="tooltip"
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <button type="button" 
                                                class="btn btn-sm btn-danger"
                                                onclick="deleteBus(<?php echo $bus['id']; ?>)"
                                                data-bs-toggle="tooltip"
                                                title="Delete Bus"
                                                <?php echo ($bus['scheduled_trips'] > 0) ? 'disabled' : ''; ?>>
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#busesTable').DataTable({
        pageLength: 25,
        order: [[0, 'asc']],
        responsive: true
    });
});

function deleteBus(busId) {
    if (confirm('Are you sure you want to delete this bus? This action cannot be undone.')) {
        fetch('delete-bus.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'bus_id=' + busId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the bus');
        });
    }
}
</script>

<?php require_once '../../includes/admin-footer.php'; ?>