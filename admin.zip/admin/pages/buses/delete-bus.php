<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has bus_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bus_id'])) {
    $bus_id = intval($_POST['bus_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Check if bus exists and can be deleted
        $stmt = $pdo->prepare("
            SELECT b.*, 
                   COUNT(DISTINCT bt.id) as scheduled_trips,
                   COUNT(DISTINCT bm.id) as maintenance_records
            FROM buses b
            LEFT JOIN bus_timings bt ON b.id = bt.bus_id
            LEFT JOIN bus_maintenance bm ON b.id = bm.bus_id
            WHERE b.id = ?
            GROUP BY b.id
        ");
        $stmt->execute([$bus_id]);
        $bus = $stmt->fetch();

        if (!$bus) {
            throw new Exception('Bus not found');
        }

        // Check if bus has no active schedules
        if ($bus['scheduled_trips'] > 0) {
            throw new Exception('Cannot delete bus with active schedules');
        }

        // Delete related records in proper order
        $statements = [
            "DELETE FROM bus_maintenance WHERE bus_id = ?",
            "DELETE FROM bus_timings WHERE bus_id = ?",
            "DELETE FROM bus_locations WHERE bus_id = ?",
            "DELETE FROM buses WHERE id = ?"
        ];

        foreach ($statements as $sql) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$bus_id]);
        }

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log("Bus deleted: ID {$bus_id} by admin {$_SESSION['admin_username']}");

        $response['success'] = true;
        $response['message'] = 'Bus deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Bus deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access attempts
    header('Location: manage-buses.php');
    exit;
}
?>