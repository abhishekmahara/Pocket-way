<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch all active routes for dropdown
    $routes = $pdo->query("SELECT route_id, route_name FROM routes WHERE is_active = 1 ORDER BY route_name")->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching routes: " . $e->getMessage());
    $error = "Unable to load routes";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $route_id = intval($_POST['route_id']);
    $bus_name = trim($_POST['bus_name']);
    $bus_number = trim($_POST['bus_number']);
    $bus_type = trim($_POST['bus_type']);
    $capacity = intval($_POST['capacity']);
    $status = $_POST['status'];

    if (empty($bus_name) || empty($bus_number)) {
        $error = 'Bus name and number are required';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO buses (
                    route_id, bus_name, bus_number, 
                    bus_type, capacity, status, 
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            
            $stmt->execute([
                $route_id, $bus_name, $bus_number,
                $bus_type, $capacity, $status
            ]);
            
            $_SESSION['success'] = 'Bus added successfully';
            header('Location: manage-buses.php');
            exit;
        } catch (PDOException $e) {
            error_log("Bus addition error: " . $e->getMessage());
            $error = 'Error adding bus. Please try again.';
        }
    }
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Add New Bus</h1>
        <a href="manage-buses.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Buses
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-bus me-1"></i>
            Bus Details
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="bus_name" class="form-label">Bus Name</label>
                        <input type="text" 
                               class="form-control" 
                               id="bus_name" 
                               name="bus_name" 
                               required
                               value="<?php echo htmlspecialchars($_POST['bus_name'] ?? ''); ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="bus_number" class="form-label">Bus Number</label>
                        <input type="text" 
                               class="form-control" 
                               id="bus_number" 
                               name="bus_number" 
                               required
                               value="<?php echo htmlspecialchars($_POST['bus_number'] ?? ''); ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="route_id" class="form-label">Select Route</label>
                        <select class="form-select" id="route_id" name="route_id" required>
                            <option value="">Select a route</option>
                            <?php foreach ($routes as $route): ?>
                                <option value="<?php echo $route['route_id']; ?>"
                                    <?php echo (isset($_POST['route_id']) && $_POST['route_id'] == $route['route_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="bus_type" class="form-label">Bus Type</label>
                        <select class="form-select" id="bus_type" name="bus_type" required>
                            <option value="Standard">Standard</option>
                            <option value="AC">AC</option>
                            <option value="Express">Express</option>
                            <option value="Deluxe">Deluxe</option>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="capacity" class="form-label">Seating Capacity</label>
                        <input type="number" 
                               class="form-control" 
                               id="capacity" 
                               name="capacity" 
                               min="1"
                               value="<?php echo htmlspecialchars($_POST['capacity'] ?? '40'); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="active">Active</option>
                        <option value="maintenance">Under Maintenance</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Bus
                    </button>
                    <a href="manage-buses.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../../includes/admin-footer.php'; ?>