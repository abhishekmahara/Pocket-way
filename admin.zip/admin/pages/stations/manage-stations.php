<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch all stations with route information
    $query = "
        SELECT s.*, 
               r.route_name,
               COUNT(DISTINCT bt.id) as bus_count,
               COUNT(DISTINCT f.id) as fare_count
        FROM stations s
        LEFT JOIN routes r ON s.route_id = r.route_id
        LEFT JOIN bus_timings bt ON s.station_id = bt.station_id
        LEFT JOIN fares f ON s.station_id = f.station_id
        GROUP BY s.station_id
        ORDER BY r.route_name, s.sequence_number";
    
    $stations = $pdo->query($query)->fetchAll();
} catch (PDOException $e) {
    error_log("Station listing error: " . $e->getMessage());
    $error = "Error loading stations";
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Manage Stations</h1>
        <a href="add-station.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Station
        </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-map-marker-alt me-1"></i>
            Station List
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="stationsTable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Station Name</th>
                            <th>Route</th>
                            <th>Sequence</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stations as $station): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($station['station_name']); ?></strong>
                                    <?php if ($station['description']): ?>
                                        <small class="d-block text-muted">
                                            <?php echo htmlspecialchars(substr($station['description'], 0, 50)); ?>...
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($station['route_name']): ?>
                                        <span class="badge bg-info">
                                            <?php echo htmlspecialchars($station['route_name']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">No Route</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        Stop #<?php echo $station['sequence_number']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $station['is_active'] ? 'success' : 'danger'; ?>">
                                        <?php echo $station['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit-station.php?id=<?php echo $station['station_id']; ?>" 
                                           class="btn btn-sm btn-warning"
                                           data-bs-toggle="tooltip"
                                           title="Edit Station">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="view-station.php?id=<?php echo $station['station_id']; ?>" 
                                           class="btn btn-sm btn-info"
                                           data-bs-toggle="tooltip"
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($station['bus_count'] == 0 && $station['fare_count'] == 0): ?>
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger"
                                                    onclick="deleteStation(<?php echo $station['station_id']; ?>)"
                                                    data-bs-toggle="tooltip"
                                                    title="Delete Station">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#stationsTable').DataTable({
        pageLength: 25,
        order: [[1, 'asc'], [2, 'asc']],
        responsive: true
    });
});

function deleteStation(stationId) {
    if (confirm('Are you sure you want to delete this station? This action cannot be undone.')) {
        fetch('delete-station.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'station_id=' + stationId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the station');
        });
    }
}
</script>

<?php require_once '../../includes/admin-footer.php'; ?>