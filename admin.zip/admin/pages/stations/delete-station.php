<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has station_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['station_id'])) {
    $station_id = intval($_POST['station_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Check if station exists and can be deleted
        $stmt = $pdo->prepare("
            SELECT s.*, 
                   COUNT(DISTINCT bt.id) as bus_count,
                   COUNT(DISTINCT f.id) as fare_count
            FROM stations s
            LEFT JOIN bus_timings bt ON s.station_id = bt.station_id
            LEFT JOIN fares f ON s.station_id = f.station_id
            WHERE s.station_id = ?
            GROUP BY s.station_id
        ");
        $stmt->execute([$station_id]);
        $station = $stmt->fetch();

        if (!$station) {
            throw new Exception('Station not found');
        }

        // Check if station has no dependencies
        if ($station['bus_count'] > 0 || $station['fare_count'] > 0) {
            throw new Exception('Cannot delete station with assigned buses or fares');
        }

        // Delete related data in order
        $statements = [
            "DELETE FROM bus_timings WHERE station_id = ?",
            "DELETE FROM route_stations WHERE station_id = ?",
            "DELETE FROM station_facilities WHERE station_id = ?",
            "DELETE FROM stations WHERE station_id = ?"
        ];

        foreach ($statements as $sql) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$station_id]);
        }

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log("Station deleted: ID {$station_id} by admin {$_SESSION['admin_username']}");

        $response['success'] = true;
        $response['message'] = 'Station deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Station deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access or invalid requests
    header('Location: manage-stations.php');
    exit;
}