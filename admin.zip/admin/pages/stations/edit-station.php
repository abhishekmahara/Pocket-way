<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Validate station ID
if (!isset($_GET['id'])) {
    header('Location: manage-stations.php');
    exit;
}

$station_id = intval($_GET['id']);

try {
    // Fetch station details
    $stmt = $pdo->prepare("SELECT * FROM stations WHERE station_id = ?");
    $stmt->execute([$station_id]);
    $station = $stmt->fetch();

    if (!$station) {
        $_SESSION['error'] = 'Station not found';
        header('Location: manage-stations.php');
        exit;
    }

    // Fetch all active routes for dropdown
    $routes = $pdo->query("SELECT route_id, route_name FROM routes WHERE is_active = 1 ORDER BY route_name")->fetchAll();

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $station_name = trim($_POST['station_name']);
        $route_id = intval($_POST['route_id']);
        $sequence_number = intval($_POST['sequence_number']);
        $description = trim($_POST['description'] ?? '');
        $latitude = floatval($_POST['latitude'] ?? 0);
        $longitude = floatval($_POST['longitude'] ?? 0);
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (empty($station_name) || empty($route_id)) {
            $error = 'Station name and route are required';
        } else {
            $stmt = $pdo->prepare("
                UPDATE stations 
                SET station_name = ?, route_id = ?, sequence_number = ?,
                    description = ?, latitude = ?, longitude = ?,
                    is_active = ?
                WHERE station_id = ?
            ");
            
            $stmt->execute([
                $station_name, $route_id, $sequence_number,
                $description, $latitude, $longitude,
                $is_active, $station_id
            ]);
            
            $_SESSION['success'] = 'Station updated successfully';
            header('Location: manage-stations.php');
            exit;
        }
    }
} catch (PDOException $e) {
    error_log("Station edit error: " . $e->getMessage());
    $error = 'System error, please try again later';
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Edit Station</h1>
        <a href="manage-stations.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Stations
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Station Details
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="station_name" class="form-label">Station Name</label>
                        <input type="text" 
                               class="form-control" 
                               id="station_name" 
                               name="station_name" 
                               required
                               value="<?php echo htmlspecialchars($station['station_name']); ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="route_id" class="form-label">Select Route</label>
                        <select class="form-select" id="route_id" name="route_id" required>
                            <option value="">Select a route</option>
                            <?php foreach ($routes as $route): ?>
                                <option value="<?php echo $route['route_id']; ?>"
                                    <?php echo ($station['route_id'] == $route['route_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="sequence_number" class="form-label">Sequence Number</label>
                        <input type="number" 
                               class="form-control" 
                               id="sequence_number" 
                               name="sequence_number" 
                               min="1"
                               value="<?php echo htmlspecialchars($station['sequence_number']); ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="latitude" class="form-label">Latitude</label>
                        <input type="number" 
                               class="form-control" 
                               id="latitude" 
                               name="latitude" 
                               step="0.000001"
                               value="<?php echo htmlspecialchars($station['latitude']); ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="longitude" class="form-label">Longitude</label>
                        <input type="number" 
                               class="form-control" 
                               id="longitude" 
                               name="longitude" 
                               step="0.000001"
                               value="<?php echo htmlspecialchars($station['longitude']); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Station Description</label>
                    <textarea class="form-control" 
                              id="description" 
                              name="description" 
                              rows="3"><?php echo htmlspecialchars($station['description']); ?></textarea>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input type="checkbox" 
                               class="form-check-input" 
                               id="is_active" 
                               name="is_active" 
                               <?php echo $station['is_active'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="is_active">Station Active</label>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Station
                    </button>
                    <a href="manage-stations.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Add validation for coordinates
    function validateCoordinates() {
        const lat = parseFloat($('#latitude').val());
        const lng = parseFloat($('#longitude').val());
        
        if (lat < -90 || lat > 90) {
            alert('Latitude must be between -90 and 90 degrees');
            return false;
        }
        if (lng < -180 || lng > 180) {
            alert('Longitude must be between -180 and 180 degrees');
            return false;
        }
        return true;
    }
    
    $('form').on('submit', function(e) {
        if (!validateCoordinates()) {
            e.preventDefault();
        }
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>