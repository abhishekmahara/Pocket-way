<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Fetch all routes with their statistics
try {
    $query = "
        SELECT r.*, 
               COUNT(DISTINCT rs.station_id) as station_count,
               COUNT(DISTINCT bt.id) as bus_count,
               MIN(s1.station_name) as start_station,
               MAX(s2.station_name) as end_station
        FROM routes r
        LEFT JOIN route_stations rs ON r.route_id = rs.route_id
        LEFT JOIN stations s1 ON rs.station_id = s1.station_id AND rs.sequence_number = 1
        LEFT JOIN stations s2 ON rs.station_id = s2.station_id 
        LEFT JOIN bus_timings bt ON r.route_id = bt.route_id
        GROUP BY r.route_id
        ORDER BY r.route_name ASC";

    $routes = $pdo->query($query)->fetchAll();
} catch (PDOException $e) {
    error_log("Route listing error: " . $e->getMessage());
    $error = "Error loading routes";
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Manage Routes</h1>
        <a href="add-route.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Route
        </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-route me-1"></i>
                Route List
            </div>
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-outline-primary" id="viewMode" data-mode="table">
                    <i class="fas fa-table"></i>
                </button>
                <button type="button" class="btn btn-sm btn-outline-primary" id="viewMode" data-mode="grid">
                    <i class="fas fa-th"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="routesTable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Route Name</th>
                            <th>Stations</th>
                            <th>Start → End</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($routes as $route): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($route['route_name']); ?></strong>
                                    <?php if ($route['description']): ?>
                                        <small class="d-block text-muted">
                                            <?php echo htmlspecialchars(substr($route['description'], 0, 50)); ?>...
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo $route['station_count']; ?> stations
                                    </span>
                                    <?php if ($route['bus_count'] > 0): ?>
                                        <span class="badge bg-secondary ms-1">
                                            <?php echo $route['bus_count']; ?> buses
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($route['start_station'] && $route['end_station']): ?>
                                        <?php echo htmlspecialchars($route['start_station']); ?> 
                                        <i class="fas fa-arrow-right text-muted mx-1"></i>
                                        <?php echo htmlspecialchars($route['end_station']); ?>
                                    <?php else: ?>
                                        <span class="text-muted">No stations assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $route['is_active'] ? 'success' : 'danger'; ?>">
                                        <?php echo $route['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit-route.php?id=<?php echo $route['route_id']; ?>" 
                                           class="btn btn-sm btn-warning"
                                           data-bs-toggle="tooltip"
                                           title="Edit Route">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="view-route.php?id=<?php echo $route['route_id']; ?>" 
                                           class="btn btn-sm btn-info"
                                           data-bs-toggle="tooltip"
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($route['station_count'] == 0): ?>
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger"
                                                    onclick="deleteRoute(<?php echo $route['route_id']; ?>)"
                                                    data-bs-toggle="tooltip"
                                                    title="Delete Route">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#routesTable').DataTable({
        pageLength: 25,
        order: [[0, 'asc']],
        responsive: true
    });
});

function deleteRoute(routeId) {
    if (confirm('Are you sure you want to delete this route? This action cannot be undone.')) {
        fetch('delete-route.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'route_id=' + routeId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the route');
        });
    }
}
</script>

<?php require_once '../../includes/admin-footer.php'; ?>