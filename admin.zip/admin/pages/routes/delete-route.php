<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has route_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['route_id'])) {
    $route_id = intval($_POST['route_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Check if route exists and can be deleted
        $stmt = $pdo->prepare("
            SELECT r.*, 
                   COUNT(DISTINCT rs.station_id) as station_count,
                   COUNT(DISTINCT b.bus_id) as bus_count
            FROM routes r
            LEFT JOIN route_stations rs ON r.route_id = rs.route_id
            LEFT JOIN buses b ON r.route_id = b.route_id
            WHERE r.route_id = ?
            GROUP BY r.route_id
        ");
        $stmt->execute([$route_id]);
        $route = $stmt->fetch();

        if (!$route) {
            throw new Exception('Route not found');
        }

        // Check if route has no dependencies
        if ($route['station_count'] > 0 || $route['bus_count'] > 0) {
            throw new Exception('Cannot delete route with assigned stations or buses');
        }

        // Delete related data in order
        $statements = [
            "DELETE FROM bus_timings WHERE route_id = ?",
            "DELETE FROM route_fares WHERE route_id = ?",
            "DELETE FROM route_maps WHERE route_id = ?",
            "DELETE FROM routes WHERE route_id = ?"
        ];

        foreach ($statements as $sql) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$route_id]);
        }

        // Delete route map file if exists
        if (!empty($route['map_image'])) {
            $map_path = __DIR__ . '/../../assets/uploads/maps/' . $route['map_image'];
            if (file_exists($map_path)) {
                unlink($map_path);
            }
        }

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log("Route deleted: ID {$route_id} by admin {$_SESSION['admin_username']}");

        $response['success'] = true;
        $response['message'] = 'Route deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Route deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access or invalid requests
    header('Location: manage-routes.php');
    exit;
}