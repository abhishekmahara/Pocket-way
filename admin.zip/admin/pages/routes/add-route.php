<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Fetch active buses
try {
    $buses = $pdo->query("SELECT id, bus_number, bus_type, capacity FROM buses WHERE status = 'active'")->fetchAll();
    $existing_routes = $pdo->query("SELECT id, route_name FROM routes WHERE status = 'active'")->fetchAll();
} catch (PDOException $e) {
    $error = "Error loading data: " . $e->getMessage();
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Add New Route</h1>
        <a href="manage-routes.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Routes
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form id="routeForm" method="POST" action="process-route.php" enctype="multipart/form-data">
        <!-- Basic Route Information -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-route me-1"></i> Basic Route Information
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Route Name*</label>
                        <input type="text" class="form-control" name="route_name" required
                               placeholder="e.g., Dehradun to Kedarnath">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Route Type*</label>
                        <select class="form-control" name="route_type" required>
                            <option value="direct">Direct Route</option>
                            <option value="connecting">Route with Connections</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Source Station*</label>
                        <input type="text" class="form-control" name="source" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Destination Station*</label>
                        <input type="text" class="form-control" name="destination" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Total Distance (km)*</label>
                        <input type="number" class="form-control" name="total_distance" 
                               step="0.1" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <label class="form-label">Route Description</label>
                        <textarea class="form-control" name="description" rows="3"
                                placeholder="Detailed description of the route including important landmarks and information"></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stations Information -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <i class="fas fa-map-marker-alt me-1"></i> Stations & Timings
            </div>
            <div class="card-body">
                <div id="stations-container">
                    <!-- Stations will be added here dynamically -->
                </div>
                <button type="button" class="btn btn-success" id="add-station">
                    <i class="fas fa-plus"></i> Add Station
                </button>
            </div>
        </div>

        <!-- Bus Schedules -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <i class="fas fa-bus me-1"></i> Bus Schedules
            </div>
            <div class="card-body">
                <div id="schedules-container">
                    <!-- Bus schedules will be added here -->
                </div>
                <button type="button" class="btn btn-info" id="add-schedule">
                    <i class="fas fa-plus"></i> Add Bus Schedule
                </button>
            </div>
        </div>

        <!-- Connecting Routes -->
        <div class="card mb-4 connecting-section" style="display: none;">
            <div class="card-header bg-secondary text-white">
                <i class="fas fa-exchange-alt me-1"></i> Connecting Routes
            </div>
            <div class="card-body">
                <div id="connections-container">
                    <!-- Connections will be added here -->
                </div>
                <button type="button" class="btn btn-secondary" id="add-connection">
                    <i class="fas fa-plus"></i> Add Connection
                </button>
            </div>
        </div>

        <!-- Route Map -->
        <div class="card mb-4">
            <div class="card-header bg-warning">
                <i class="fas fa-map me-1"></i> Route Map & Additional Information
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Upload Route Map</label>
                        <input type="file" class="form-control" name="route_map" accept="image/*">
                        <small class="text-muted">Upload a clear map showing the complete route with stations</small>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Special Instructions</label>
                        <textarea class="form-control" name="special_instructions" rows="3"
                                placeholder="Any special instructions or notes for passengers"></textarea>
                    </div>
                </div>
                <div id="map-preview" class="mt-3 d-none">
                    <img src="" alt="Route Map Preview" class="img-fluid rounded">
                </div>
            </div>
        </div>

        <!-- Submit Section -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="is_active" name="is_active" checked>
                    <label class="form-check-label" for="is_active">
                        Activate this route immediately
                    </label>
                </div>
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i> Save Complete Route
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Templates -->
<template id="station-template">
    <div class="station-entry border rounded p-3 mb-3">
        <h5 class="d-flex justify-content-between">
            <span>Station #<span class="station-number"></span></span>
            <button type="button" class="btn btn-danger btn-sm remove-station">
                <i class="fas fa-times"></i>
            </button>
        </h5>
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Station Name*</label>
                <input type="text" class="form-control" name="stations[{index}][name]" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Distance from Previous (km)*</label>
                <input type="number" class="form-control distance-input" 
                       name="stations[{index}][distance]" step="0.1" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Cumulative Distance (km)</label>
                <input type="number" class="form-control cumulative-distance" 
                       name="stations[{index}][cumulative_distance]" readonly>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-3">
                <label class="form-label">Base Fare (₹)*</label>
                <input type="number" class="form-control" 
                       name="stations[{index}][base_fare]" step="0.01" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Expected Time from Previous*</label>
                <input type="time" class="form-control" 
                       name="stations[{index}][time_from_prev]" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Stop Duration</label>
                <input type="text" class="form-control" 
                       name="stations[{index}][stop_duration]" 
                       placeholder="e.g., 5 minutes">
            </div>
            <div class="col-md-3">
                <label class="form-label">Platform/Stop Number</label>
                <input type="text" class="form-control" 
                       name="stations[{index}][platform]" 
                       placeholder="e.g., Platform 1">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">GPS Coordinates</label>
                <div class="input-group">
                    <input type="text" class="form-control" 
                           name="stations[{index}][latitude]" 
                           placeholder="Latitude">
                    <input type="text" class="form-control" 
                           name="stations[{index}][longitude]" 
                           placeholder="Longitude">
                </div>
            </div>
            <div class="col-md-6">
                <label class="form-label">Station Facilities</label>
                <input type="text" class="form-control" 
                       name="stations[{index}][facilities]" 
                       placeholder="e.g., Waiting Room, Refreshments">
            </div>
        </div>
    </div>
</template>

<template id="schedule-template">
    <div class="schedule-entry border rounded p-3 mb-3">
        <h5 class="d-flex justify-content-between">
            <span>Schedule #<span class="schedule-number"></span></span>
            <button type="button" class="btn btn-danger btn-sm remove-schedule">
                <i class="fas fa-times"></i>
            </button>
        </h5>
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Select Bus*</label>
                <select class="form-control" name="schedules[{index}][bus_id]" required>
                    <option value="">Choose a bus</option>
                    <?php foreach ($buses as $bus): ?>
                        <option value="<?php echo $bus['id']; ?>">
                            <?php echo htmlspecialchars($bus['bus_number'] . ' (' . $bus['bus_type'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">First Departure*</label>
                <input type="time" class="form-control" 
                       name="schedules[{index}][first_departure]" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Last Departure</label>
                <input type="time" class="form-control" 
                       name="schedules[{index}][last_departure]">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Frequency*</label>
                <select class="form-control" name="schedules[{index}][frequency]" required>
                    <option value="daily">Daily</option>
                    <option value="weekday">Weekdays Only</option>
                    <option value="weekend">Weekends Only</option>
                    <option value="custom">Custom Schedule</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Operating Days</label>
                <input type="text" class="form-control" 
                       name="schedules[{index}][operating_days]" 
                       placeholder="e.g., Mon,Tue,Wed">
            </div>
            <div class="col-md-4">
                <label class="form-label">Service Type</label>
                <select class="form-control" name="schedules[{index}][service_type]">
                    <option value="regular">Regular</option>
                    <option value="express">Express</option>
                    <option value="superfast">Super Fast</option>
                </select>
            </div>
        </div>
    </div>
</template>

<script>
$(document).ready(function() {
    let stationCount = 0;
    let scheduleCount = 0;

    // Show/hide connecting routes section
    $('select[name="route_type"]').change(function() {
        $('.connecting-section').toggle($(this).val() === 'connecting');
    });

    // Add station
    $('#add-station').click(function() {
        const template = $('#station-template').html();
        const station = template.replace(/{index}/g, stationCount);
        $('#stations-container').append(station);
        $('.station-number').last().text(stationCount + 1);
        stationCount++;
        updateDistances();
    });

    // Add schedule
    $('#add-schedule').click(function() {
        const template = $('#schedule-template').html();
        const schedule = template.replace(/{index}/g, scheduleCount);
        $('#schedules-container').append(schedule);
        $('.schedule-number').last().text(scheduleCount + 1);
        scheduleCount++;
    });

    // Remove station
    $(document).on('click', '.remove-station', function() {
        $(this).closest('.station-entry').remove();
        updateStationNumbers();
        updateDistances();
    });

    // Remove schedule
    $(document).on('click', '.remove-schedule', function() {
        $(this).closest('.schedule-entry').remove();
        updateScheduleNumbers();
    });

    // Update distances
    $(document).on('change', '.distance-input', function() {
        updateDistances();
    });

    function updateDistances() {
        let total = 0;
        $('.station-entry').each(function() {
            const distance = parseFloat($(this).find('.distance-input').val()) || 0;
            total += distance;
            $(this).find('.cumulative-distance').val(total.toFixed(1));
        });
        $('input[name="total_distance"]').val(total.toFixed(1));
    }

    function updateStationNumbers() {
        $('.station-number').each(function(index) {
            $(this).text(index + 1);
        });
    }

    function updateScheduleNumbers() {
        $('.schedule-number').each(function(index) {
            $(this).text(index + 1);
        });
    }

    // Route map preview
    $('input[name="route_map"]').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#map-preview').removeClass('d-none')
                    .find('img').attr('src', e.target.result);
            }
            reader.readAsDataURL(file);
        }
    });

    // Form validation
    $('#routeForm').submit(function(e) {
        if ($('#stations-container').children().length < 2) {
            e.preventDefault();
            alert('Please add at least two stations for the route');
            return false;
        }
        if ($('#schedules-container').children().length === 0) {
            e.preventDefault();
            alert('Please add at least one bus schedule');
            return false;
        }
        return true;
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>