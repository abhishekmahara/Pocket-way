<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Validate route ID
if (!isset($_GET['id'])) {
    header('Location: manage-routes.php');
    exit;
}

$route_id = intval($_GET['id']);

try {
    // Fetch route details
    $stmt = $pdo->prepare("SELECT * FROM routes WHERE route_id = ?");
    $stmt->execute([$route_id]);
    $route = $stmt->fetch();

    if (!$route) {
        $_SESSION['error'] = 'Route not found';
        header('Location: manage-routes.php');
        exit;
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $route_name = trim($_POST['route_name']);
        $description = trim($_POST['description'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $base_fare = floatval($_POST['base_fare'] ?? 0);

        if (empty($route_name)) {
            $error = 'Route name is required';
        } else {
            $stmt = $pdo->prepare("
                UPDATE routes 
                SET route_name = ?, description = ?, is_active = ?, base_fare = ?
                WHERE route_id = ?
            ");
            $stmt->execute([$route_name, $description, $is_active, $base_fare, $route_id]);
            
            $_SESSION['success'] = 'Route updated successfully';
            header('Location: manage-routes.php');
            exit;
        }
    }
} catch (PDOException $e) {
    error_log("Route edit error: " . $e->getMessage());
    $error = 'System error, please try again later';
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Edit Route</h1>
        <a href="manage-routes.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Routes
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Route Details
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="route_name" class="form-label">Route Name</label>
                        <input type="text" 
                               class="form-control" 
                               id="route_name" 
                               name="route_name" 
                               required
                               value="<?php echo htmlspecialchars($route['route_name']); ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="base_fare" class="form-label">Base Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="base_fare" 
                               name="base_fare" 
                               step="0.01" 
                               min="0"
                               value="<?php echo htmlspecialchars($route['base_fare']); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Route Description</label>
                    <textarea class="form-control" 
                              id="description" 
                              name="description" 
                              rows="3"><?php echo htmlspecialchars($route['description']); ?></textarea>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input type="checkbox" 
                               class="form-check-input" 
                               id="is_active" 
                               name="is_active" 
                               <?php echo $route['is_active'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="is_active">Route Active</label>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Route
                    </button>
                    <a href="manage-routes.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Route Statistics -->
    <?php
    // Fetch route statistics
    $stats = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT rs.station_id) as station_count,
            COUNT(DISTINCT b.bus_id) as bus_count,
            COUNT(DISTINCT bt.timing_id) as timing_count
        FROM routes r
        LEFT JOIN route_stations rs ON r.route_id = rs.route_id
        LEFT JOIN buses b ON r.route_id = b.route_id
        LEFT JOIN bus_timings bt ON r.route_id = bt.route_id
        WHERE r.route_id = ?
    ");
    $stats->execute([$route_id]);
    $routeStats = $stats->fetch();
    ?>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-chart-bar me-1"></i>
            Route Statistics
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 text-center">
                    <h4><?php echo $routeStats['station_count']; ?></h4>
                    <p class="text-muted">Stations</p>
                </div>
                <div class="col-md-4 text-center">
                    <h4><?php echo $routeStats['bus_count']; ?></h4>
                    <p class="text-muted">Buses</p>
                </div>
                <div class="col-md-4 text-center">
                    <h4><?php echo $routeStats['timing_count']; ?></h4>
                    <p class="text-muted">Timings</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/admin-footer.php'; ?>