/XAMPP/xamppfiles/htdocs/Pocket-way/admin/pages/maps/delete-map.php
<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has map_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['map_id'])) {
    $map_id = intval($_POST['map_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Get map details
        $stmt = $pdo->prepare("SELECT map_image, route_id FROM route_maps WHERE id = ?");
        $stmt->execute([$map_id]);
        $map = $stmt->fetch();

        if (!$map) {
            throw new Exception('Map not found');
        }

        // Delete the physical file
        $file_path = __DIR__ . '/../../assets/uploads/maps/' . $map['map_image'];
        if (file_exists($file_path)) {
            if (!unlink($file_path)) {
                throw new Exception('Failed to delete map file');
            }
        }

        // Delete database record
        $stmt = $pdo->prepare("DELETE FROM route_maps WHERE id = ?");
        $stmt->execute([$map_id]);

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log("Map deleted: ID {$map_id}, File: {$map['map_image']} by admin {$_SESSION['admin_username']}");

        $response['success'] = true;
        $response['message'] = 'Map deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Map deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access or invalid requests
    header('Location: manage-maps.php');
    exit;
}