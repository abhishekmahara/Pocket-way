<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch all active routes
    $routes = $pdo->query("
        SELECT route_id, route_name 
        FROM routes 
        WHERE is_active = 1 
        ORDER BY route_name
    ")->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching routes: " . $e->getMessage());
    $error = "Unable to load routes";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $route_id = intval($_POST['route_id']);
    $map_file = $_FILES['map_image'];
    
    if (empty($route_id)) {
        $error = 'Please select a route';
    } elseif ($map_file['error'] !== 0) {
        $error = 'Please select a map image';
    } else {
        try {
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_info = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($file_info, $map_file['tmp_name']);
            finfo_close($file_info);

            if (!in_array($mime_type, $allowed_types)) {
                throw new Exception('Invalid file type. Only JPG, PNG and GIF are allowed.');
            }

            // Generate unique filename
            $file_extension = pathinfo($map_file['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid('map_') . '.' . $file_extension;
            $upload_path = __DIR__ . '/../../assets/uploads/maps/' . $new_filename;

            // Move uploaded file
            if (!move_uploaded_file($map_file['tmp_name'], $upload_path)) {
                throw new Exception('Failed to upload file');
            }

            // Save to database
            $stmt = $pdo->prepare("
                INSERT INTO route_maps (
                    route_id, map_image, uploaded_by, created_at
                ) VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ");
            
            $stmt->execute([
                $route_id, 
                $new_filename,
                $_SESSION['admin_id']
            ]);
            
            $_SESSION['success'] = 'Map uploaded successfully';
            header('Location: manage-maps.php');
            exit;

        } catch (Exception $e) {
            error_log("Map upload error: " . $e->getMessage());
            $error = $e->getMessage();
            
            // Clean up uploaded file if exists
            if (isset($upload_path) && file_exists($upload_path)) {
                unlink($upload_path);
            }
        }
    }
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Upload Route Map</h1>
        <a href="manage-maps.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Maps
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-map me-1"></i>
            Map Details
        </div>
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="route_id" class="form-label">Select Route</label>
                        <select class="form-select" id="route_id" name="route_id" required>
                            <option value="">Select a route</option>
                            <?php foreach ($routes as $route): ?>
                                <option value="<?php echo $route['route_id']; ?>">
                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="map_image" class="form-label">Map Image</label>
                        <input type="file" 
                               class="form-control" 
                               id="map_image" 
                               name="map_image" 
                               accept="image/*"
                               required>
                        <small class="text-muted">
                            Supported formats: JPG, PNG, GIF. Max size: 5MB
                        </small>
                    </div>
                </div>

                <div id="imagePreview" class="mb-3 d-none">
                    <img src="" alt="Preview" class="img-fluid" style="max-height: 300px;">
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload me-1"></i> Upload Map
                    </button>
                    <a href="manage-maps.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Image preview
    $('#map_image').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview img').attr('src', e.target.result);
                $('#imagePreview').removeClass('d-none');
            }
            reader.readAsDataURL(file);
        }
    });

    // File validation
    $('form').submit(function(e) {
        const file = $('#map_image')[0].files[0];
        if (file && file.size > 5 * 1024 * 1024) {
            alert('File size exceeds 5MB limit');
            e.preventDefault();
        }
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>