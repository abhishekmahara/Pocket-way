<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

try {
    // Fetch all fares with detailed information
    $query = "
        SELECT f.*, 
               s.station_name,
               r.route_name,
               r.route_id
        FROM fares f
        JOIN stations s ON f.station_id = s.station_id
        JOIN routes r ON s.route_id = r.route_id
        ORDER BY r.route_name, s.sequence_number";
    
    $fares = $pdo->query($query)->fetchAll();
} catch (PDOException $e) {
    error_log("Fare listing error: " . $e->getMessage());
    $error = "Error loading fares";
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Manage Fares</h1>
        <a href="add-fare.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Fare
        </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-money-bill me-1"></i>
            Fare List
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="faresTable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Route</th>
                            <th>Station</th>
                            <th>Base Fare (₹)</th>
                            <th>Peak Hour Fare (₹)</th>
                            <th>Last Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fares as $fare): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo htmlspecialchars($fare['route_name']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($fare['station_name']); ?></td>
                                <td>₹<?php echo number_format($fare['base_fare'], 2); ?></td>
                                <td>
                                    <?php if ($fare['peak_fare']): ?>
                                        ₹<?php echo number_format($fare['peak_fare'], 2); ?>
                                    <?php else: ?>
                                        <span class="text-muted">Not set</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo date('d M Y, h:i A', strtotime($fare['updated_at'])); ?>
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit-fare.php?id=<?php echo $fare['fare_id']; ?>" 
                                           class="btn btn-sm btn-warning"
                                           data-bs-toggle="tooltip"
                                           title="Edit Fare">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" 
                                                class="btn btn-sm btn-danger"
                                                onclick="deleteFare(<?php echo $fare['fare_id']; ?>)"
                                                data-bs-toggle="tooltip"
                                                title="Delete Fare">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#faresTable').DataTable({
        pageLength: 25,
        order: [[0, 'asc'], [1, 'asc']],
        responsive: true
    });
});

function deleteFare(fareId) {
    if (confirm('Are you sure you want to delete this fare? This action cannot be undone.')) {
        fetch('delete-fare.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'fare_id=' + fareId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the fare');
        });
    }
}
</script>

<?php require_once '../../includes/admin-footer.php'; ?>