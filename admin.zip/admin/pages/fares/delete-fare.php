<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';

// Check if request is POST and has fare_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fare_id'])) {
    $fare_id = intval($_POST['fare_id']);
    $response = ['success' => false, 'message' => ''];

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Check if fare exists
        $stmt = $pdo->prepare("
            SELECT f.*, s.station_name, r.route_name 
            FROM fares f
            JOIN stations s ON f.station_id = s.station_id
            JOIN routes r ON s.route_id = r.route_id
            WHERE f.fare_id = ?
        ");
        $stmt->execute([$fare_id]);
        $fare = $stmt->fetch();

        if (!$fare) {
            throw new Exception('Fare not found');
        }

        // Delete associated records
        $statements = [
            "DELETE FROM fare_history WHERE fare_id = ?",
            "DELETE FROM fares WHERE fare_id = ?"
        ];

        foreach ($statements as $sql) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$fare_id]);
        }

        // Commit transaction
        $pdo->commit();

        // Log the deletion
        error_log("Fare deleted: ID {$fare_id} for station {$fare['station_name']} on route {$fare['route_name']} by admin {$_SESSION['admin_username']}");

        $response['success'] = true;
        $response['message'] = 'Fare deleted successfully';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Fare deletion error: " . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;

} else {
    // Handle direct access or invalid requests
    header('Location: manage-fares.php');
    exit;
}