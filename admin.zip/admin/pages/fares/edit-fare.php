<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

// Validate fare ID
if (!isset($_GET['id'])) {
    header('Location: manage-fares.php');
    exit;
}

$fare_id = intval($_GET['id']);

try {
    // Fetch fare details with station and route info
    $stmt = $pdo->prepare("
        SELECT f.*, s.station_name, r.route_name, r.route_id
        FROM fares f
        JOIN stations s ON f.station_id = s.station_id
        JOIN routes r ON s.route_id = r.route_id
        WHERE f.fare_id = ?
    ");
    $stmt->execute([$fare_id]);
    $fare = $stmt->fetch();

    if (!$fare) {
        $_SESSION['error'] = 'Fare not found';
        header('Location: manage-fares.php');
        exit;
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $base_fare = floatval($_POST['base_fare']);
        $peak_fare = !empty($_POST['peak_fare']) ? floatval($_POST['peak_fare']) : null;
        $special_fare = !empty($_POST['special_fare']) ? floatval($_POST['special_fare']) : null;

        if ($base_fare <= 0) {
            $error = 'Base fare must be greater than 0';
        } else {
            $stmt = $pdo->prepare("
                UPDATE fares 
                SET base_fare = ?, 
                    peak_fare = ?, 
                    special_fare = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE fare_id = ?
            ");
            
            $stmt->execute([$base_fare, $peak_fare, $special_fare, $fare_id]);
            
            $_SESSION['success'] = 'Fare updated successfully';
            header('Location: manage-fares.php');
            exit;
        }
    }
} catch (PDOException $e) {
    error_log("Fare edit error: " . $e->getMessage());
    $error = 'System error, please try again later';
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Edit Fare</h1>
        <a href="manage-fares.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Fares
        </a>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-money-bill me-1"></i>
            Fare Details
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5 class="text-muted mb-3">Route Information</h5>
                    <p>
                        <strong>Route:</strong> 
                        <span class="badge bg-info">
                            <?php echo htmlspecialchars($fare['route_name']); ?>
                        </span>
                    </p>
                    <p>
                        <strong>Station:</strong> 
                        <?php echo htmlspecialchars($fare['station_name']); ?>
                    </p>
                </div>
            </div>

            <form method="POST" action="" id="fareForm">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="base_fare" class="form-label">Base Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="base_fare" 
                               name="base_fare" 
                               step="0.01" 
                               min="0" 
                               required
                               value="<?php echo htmlspecialchars($fare['base_fare']); ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="peak_fare" class="form-label">Peak Hour Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="peak_fare" 
                               name="peak_fare" 
                               step="0.01" 
                               min="0"
                               value="<?php echo htmlspecialchars($fare['peak_fare'] ?? ''); ?>">
                        <small class="text-muted">Optional</small>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="special_fare" class="form-label">Special Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="special_fare" 
                               name="special_fare" 
                               step="0.01" 
                               min="0"
                               value="<?php echo htmlspecialchars($fare['special_fare'] ?? ''); ?>">
                        <small class="text-muted">Optional</small>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Fare
                    </button>
                    <a href="manage-fares.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Form validation
    $('#fareForm').on('submit', function(e) {
        const baseFare = parseFloat($('#base_fare').val());
        const peakFare = parseFloat($('#peak_fare').val());
        
        if (peakFare && peakFare <= baseFare) {
            e.preventDefault();
            alert('Peak hour fare should be higher than base fare');
            return false;
        }
        return true;
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>