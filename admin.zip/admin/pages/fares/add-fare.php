<?php
require_once '../../includes/auth-check.php';
require_once '../../includes/db-config.php';
require_once '../../includes/admin-header.php';

$error = '';

try {
    // Fetch all active routes and their stations
    $query = "
        SELECT s.station_id, s.station_name, 
               r.route_id, r.route_name,
               s.sequence_number
        FROM stations s 
        JOIN routes r ON s.route_id = r.route_id 
        WHERE r.is_active = 1
        ORDER BY r.route_name, s.sequence_number";
    
    $stations = $pdo->query($query)->fetchAll();
    
    // Group stations by route
    $routes = [];
    foreach ($stations as $station) {
        if (!isset($routes[$station['route_id']])) {
            $routes[$station['route_id']] = [
                'route_name' => $station['route_name'],
                'stations' => []
            ];
        }
        $routes[$station['route_id']]['stations'][] = $station;
    }

} catch (PDOException $e) {
    error_log("Error fetching stations: " . $e->getMessage());
    $error = "Unable to load stations";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $station_id = intval($_POST['station_id']);
    $base_fare = floatval($_POST['base_fare']);
    $peak_fare = !empty($_POST['peak_fare']) ? floatval($_POST['peak_fare']) : null;
    $special_fare = !empty($_POST['special_fare']) ? floatval($_POST['special_fare']) : null;

    if (empty($station_id) || $base_fare <= 0) {
        $error = 'Please provide valid station and base fare';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO fares (
                    station_id, base_fare, peak_fare, 
                    special_fare, created_at, updated_at
                ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ");
            
            $stmt->execute([$station_id, $base_fare, $peak_fare, $special_fare]);
            
            $_SESSION['success'] = 'Fare added successfully';
            header('Location: manage-fares.php');
            exit;
        } catch (PDOException $e) {
            error_log("Fare addition error: " . $e->getMessage());
            $error = 'Error adding fare. Please try again.';
        }
    }
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Add New Fare</h1>
        <a href="manage-fares.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Fares
        </a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-money-bill me-1"></i>
            Fare Details
        </div>
        <div class="card-body">
            <form method="POST" action="" id="fareForm">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="station_id" class="form-label">Select Route & Station</label>
                        <select class="form-select" id="station_id" name="station_id" required>
                            <option value="">Select station</option>
                            <?php foreach ($routes as $route_id => $route): ?>
                                <optgroup label="<?php echo htmlspecialchars($route['route_name']); ?>">
                                    <?php foreach ($route['stations'] as $station): ?>
                                        <option value="<?php echo $station['station_id']; ?>">
                                            Stop #<?php echo $station['sequence_number']; ?> - 
                                            <?php echo htmlspecialchars($station['station_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="base_fare" class="form-label">Base Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="base_fare" 
                               name="base_fare" 
                               step="0.01" 
                               min="0" 
                               required>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="peak_fare" class="form-label">Peak Hour Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="peak_fare" 
                               name="peak_fare" 
                               step="0.01" 
                               min="0">
                        <small class="text-muted">Optional</small>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="special_fare" class="form-label">Special Fare (₹)</label>
                        <input type="number" 
                               class="form-control" 
                               id="special_fare" 
                               name="special_fare" 
                               step="0.01" 
                               min="0">
                        <small class="text-muted">Optional</small>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Fare
                    </button>
                    <a href="manage-fares.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Initialize select2 for better dropdown experience
    $('#station_id').select2({
        theme: 'bootstrap-5',
        width: '100%'
    });

    // Form validation
    $('#fareForm').on('submit', function(e) {
        const baseFare = parseFloat($('#base_fare').val());
        const peakFare = parseFloat($('#peak_fare').val());
        
        if (peakFare && peakFare <= baseFare) {
            e.preventDefault();
            alert('Peak hour fare should be higher than base fare');
            return false;
        }
        return true;
    });
});
</script>

<?php require_once '../../includes/admin-footer.php'; ?>